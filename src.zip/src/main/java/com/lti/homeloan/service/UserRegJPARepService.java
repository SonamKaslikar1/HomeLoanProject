package com.lti.homeloan.service;

import org.springframework.data.jpa.repository.JpaRepository;

public class UserRegJPARepService  {

}
